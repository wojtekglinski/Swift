//
//  ViewController.swift
//  RandomColorGenerator2
//
//  Created by harper on 2/14/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var redLabel: UILabel!
    @IBOutlet weak var greenLabel: UILabel!
    @IBOutlet weak var blueLabel: UILabel!
    @IBOutlet weak var randomColorButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        redLabel.text = "Red 0"
        redLabel.textColor = UIColor.red
        greenLabel.text = "Green 0"
        greenLabel.textColor = UIColor.green
        blueLabel.text = "Blue 0"
        blueLabel.textColor = UIColor.blue
        randomColorButton.setTitle("Color Change", for: .normal)

    
    }

    @IBAction func onRandomColorButtonPressed(_ sender: UIButton) {
        let red = CGFloat.random(in: 0...1)
        let green = CGFloat.random(in: 0...1)
        let blue = CGFloat.random(in: 0...1)
        let alpha = CGFloat.random(in: 0...1)
        view.backgroundColor = UIColor(red: red, green: green, blue: blue, alpha: alpha)
        redLabel.text = "Red: \(red)"
        greenLabel.text = "Green: \(green)"
        blueLabel.text = "Blue: \(blue)"
        randomColorButton.backgroundColor = UIColor(red: blue, green: red, blue: green, alpha: 1.0)
        }
        
    
        
        
        
        
        
    
    
}

