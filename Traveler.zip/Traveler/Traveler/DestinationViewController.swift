//
//  DestinationViewController.swift
//  Traveler
//
//  Created by harper on 3/7/21.
//

import UIKit

class DestinationViewController: UIViewController {
var travelDestinationPassed = "oregon"
    
    
    @IBOutlet weak var oregonImageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        oregonImageView.image = UIImage(named: travelDestinationPassed.lowercased())
        title = "Welcome to \(travelDestinationPassed)!"
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let dvc = segue.destination as!
        ViewController
        dvc.returnDestination = travelDestinationPassed
        
    }

 
}
