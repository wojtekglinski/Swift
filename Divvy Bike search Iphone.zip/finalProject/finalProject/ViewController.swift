//
//  ViewController.swift
//  finalProject
//
//  Created by harper on 5/4/21.
//

import UIKit
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, UITableViewDataSource, UITableViewDelegate, MKMapViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return station.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellID", for: indexPath)
        let stations = station[indexPath.row]
        cell.textLabel?.text = stations.station_name
        if let userLocation = userLocation, let docksInService = stations.docks_in_service {
            cell.detailTextLabel?.numberOfLines = 0
            cell.detailTextLabel?.text = "\(docksInService)\n\(Int(stations.distance(to: userLocation))) meters"
        }
        return cell
        
    

        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let dvc = segue.destination as! DetailViewController
        if let indexPath = tableView.indexPathForSelectedRow{
            let stationDetail = station[indexPath.row]
            dvc.station = stationDetail

        }
        
    }
    
    
    var userLocation: CLLocation?
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var mapKitView: MKMapView!
    var locationManager = CLLocationManager()
    var station = [Divy]()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        mapKitView.showsUserLocation = true
        mapKitView.delegate = self
        /*stations.fetchDivy { (divvyStations) in
         self.station = divvyStations
         self.tableView.reloadData()
         print(self.station)
         }*/
        tableView.isHidden = true
    
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("updated location" + (locations.first?.coordinate.latitude.description)!)
        centerToLocation(location: locations.first!)
        locationManager.stopUpdatingLocation()
        if let userLocation = locations.first {
            self.userLocation = userLocation
            let center = userLocation.coordinate
            let span = MKCoordinateSpan(latitudeDelta: 0.03, longitudeDelta: 0.03)
            let region = MKCoordinateRegion(center: center, span: span)
            mapKitView.setRegion(region, animated: true)
            fetchDivy()
            print("user location", userLocation)
        }
        
    }
    func centerToLocation(location: CLLocation){
        let regionRadius: CLLocationDistance = 10000
        let cordinateRegion = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
        mapKitView.setRegion(cordinateRegion, animated: true)
        
        
        
        
    }

    func fetchDivy() {
        stations.fetchDivy { [self] (Divy) in
            self.station = Divy
            if let userLocation = self.userLocation{
                self.station.sort(by: {$0.distance(to: userLocation) <
                    $1.distance(to: userLocation)})
            }
            for station in self.station{
                print(station.station_name)
                print(station.distance(to: userLocation!))
                self.addAnnotationForStation(station: station)
                
                
            }
            self.tableView.reloadData()
        }
    }
    func addAnnotationForStation(station: Divy){
        let annotation = MKPointAnnotation()
        annotation.coordinate = station.coordinate!
        annotation.title = station.station_name
        mapKitView.addAnnotation(annotation)
        if let userLocation = self.userLocation {
            annotation.subtitle = Int(station.distance(to: userLocation)).description
        }
        
    }
    @IBAction func segmentedControlValue(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            tableView.isHidden = true
            mapKitView.isHidden = false
        }
        else {
            tableView.isHidden = false
            mapKitView.isHidden = true
        }
        
    }
    
    
}
