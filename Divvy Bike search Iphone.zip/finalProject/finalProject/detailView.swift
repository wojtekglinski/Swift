//
//  detailView.swift
//  finalProject
//
//  Created by harper on 5/14/21.
//

import UIKit

class detailView: UIImageView {

    @IBOutlet weak var txtView: UITextView!
    

    
    

}
