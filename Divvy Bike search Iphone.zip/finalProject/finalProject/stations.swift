//
//  stations.swift
//  finalProject
//
//  Created by harper on 5/4/21.
//

import Foundation
enum stations {
    static func fetchDivy(completion: @escaping ([Divy]) ->Void){
        let jasonURLString = "https://data.cityofchicago.org/resource/bbyy-e7gq.json"
        guard let url = URL(string: jasonURLString) else { return }
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else { return }
            do {
                let divvyStations = try JSONDecoder().decode([Divy].self, from: data)
                DispatchQueue.main.async {
                    completion(divvyStations)
                
                }
                
            }
            catch let jsonError{
                print("Error Serializing JSON", jsonError)
            }
        
        }.resume()
        
        
    }
}
