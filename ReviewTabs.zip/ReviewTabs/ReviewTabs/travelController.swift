//
//  travelController.swift
//  ReviewTabs
//
//  Created by harper on 4/5/21.
//

import UIKit

class travelController: UIViewController {
    @IBOutlet weak var travelImg: UIImageView!
    
    @IBOutlet weak var travelTxt: UILabel!
    override func viewDidLoad() {
        view.backgroundColor = .cyan
        super.viewDidLoad()
        travelTxt.text = "Gain skills, advance your career, begin your bachelor's degree. Harper is a top Illinois' college and career training school. Compare our affordable tuition."
        

    }


}
