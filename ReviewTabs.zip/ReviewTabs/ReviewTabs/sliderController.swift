//
//  sliderController.swift
//  ReviewTabs
//
//  Created by harper on 4/5/21.
//

import UIKit

class sliderController: UIViewController {
    @IBOutlet weak var imgSlider: UISlider!
    @IBOutlet weak var imgView: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    @IBAction func imgSlider(_ sender: UISlider) {
        let image = Int(sender.value)
        imgView.image = UIImage(named: image.description)

        
    }
    
        

}
