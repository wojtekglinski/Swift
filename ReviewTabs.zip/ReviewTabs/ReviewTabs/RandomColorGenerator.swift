//
//  RandomColorGenerator.swift
//  ReviewTabs
//
//  Created by harper on 4/5/21.
//

import UIKit

class RandomColorGenerator: UIViewController {

    @IBOutlet weak var colorChange: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func colorChange(_ sender: UIButton) {
        let red = CGFloat.random(in: 0...1)
        let green = CGFloat.random(in: 0...1)
        let blue = CGFloat.random(in: 0...1)
        let alpha = CGFloat.random(in: 0...1)
        view.backgroundColor = UIColor(red: red, green: green, blue: blue, alpha: alpha)
        colorChange.tintColor = UIColor(red: blue, green: red, blue: green, alpha: 1.0)

        
        
        
    }
}
