//
//  Calc.swift
//  ReviewTabs
//
//  Created by harper on 4/5/21.
//

import UIKit

class Calc: UIViewController {

    @IBOutlet weak var txtfield1: UITextField!
    @IBOutlet weak var txtfield2: UITextField!
    @IBOutlet weak var opLabel: UILabel!
    @IBOutlet weak var displayLabel: UILabel!
    @IBOutlet weak var operationSegment: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func segmentSelect(_ sender: UISegmentedControl) {
        opLabel.text = sender.titleForSegment(at: sender.selectedSegmentIndex)

        
        
        
        
        
        
        
    }
    @IBAction func calcButton(_ sender: UIButton) {
        let number1 = Int(txtfield1.text!)
        let number2 = Int(txtfield2.text!)
        var result = 0
        
        
        
        
        switch operationSegment.selectedSegmentIndex {
        case 0:
            result = number1! + number2!
        case 1:
            result = number1! - number2!
        case 2:
            result = number1! * number2!

        default:
            result = number1! / number2!
        
        
        
        }
            displayLabel.text = "\(result)"
        txtfield1.text = ""
        txtfield2.text = ""
        txtfield1.resignFirstResponder()
        txtfield2.resignFirstResponder()
    
    
    
    
    }
    

}
