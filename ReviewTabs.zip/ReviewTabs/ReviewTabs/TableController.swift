//
//  TableController.swift
//  ReviewTabs
//
//  Created by harper on 4/5/21.
//

import UIKit

class TableController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var txtField: UITextField!
    
    

    @IBOutlet weak var tblView: UITableView!
    var shopping = ["Make bed", "Make breakfast", "Shower", "Feed the dog"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shopping.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath)
        cell.textLabel?.text = shopping [indexPath.row]
        return cell
    }

    @IBAction func addButton(_ sender: UIBarButtonItem) {
        shopping.append(txtField.text!)
        txtField.text = ""
        tblView.reloadData()
    
    
    
    }
}
